﻿<#
.Synopsis
   This script is used to query VirusTotal for any SHA1, MD5 or Sha256 hash hits. The script is limited by VT public API key. 
   You can only do 4 submissions per minute. 


.DESCRIPTION
   Before you rerun the script be sure that the minute has lapsed before you do or it wont work. 
.EXAMPLE
   Here is an example on how to use this script 
   .\VT-SubmitHash-BsidesV1.ps1 myHashes.txt
   
   Use this if you have to bypass the execution policy
  set-executionpolicy bypass -file VT-SubmitHash-BsidesV1.ps1
  or 
  powershell -executionpolicy bypass -file VT-SubmitHash-BsidesV1.ps1
  
#>

Param ([String]$HashFileName)

# Import Powershell Module. When using splunk to call the PS command I had to embed into this directly into script 
Import-Module  .\virustotalv2.psm1


# This command will verify that the above module loaded successfully
# get-command -Module virustotalv2

#k_inkster VTAPI key

# Zeros out our hash tables
$Hashes = @()
$VT = 0
$MyOut = @()
$VTError = @()
$NewObj = @()
$NewFileSubmit=@()


# This function is used to query VT, write to host and put into various arrays for output
Function MyFunction ($item)
      { 
        $VT = (Get-VTReport -hash $item) 
        
        if ($VT.verbose_msg -like "Scan finished*")
            { Foreach-object {"{0}/{1} sha1 {2,-35} MD5 {3} {4} {5} {6} " -f $VT.positives,$VT.total,$VT.sha1,$VT.md5,$VT.response_code,$VT.verbose_msg,$VT.scan_date}
             $NewObj = New-Object System.Object
             $NewObj | Add-Member -type NoteProperty -name Hashes -value ("SHA1="+$VT.sha1.ToUpper())
             $NewObj | Add-Member -type NoteProperty -name Positives -value $VT.positives
             $NewObj | Add-Member -type NoteProperty -name Total -value $VT.total
             $NewObj | Add-Member -type NoteProperty -name response_code -value $VT.response_code
             $NewObj | Add-Member -type NoteProperty -name Message -value $VT.verbose_msg
             $NewObj | Add-Member -type NoteProperty -name ScanDate -value $VT.scan_date
             $MyOut += $NewObj
             }

       elseIf ($VT.verbose_msg -like "The requested resource is not*")   
            {
            Write-Host $VT.response_code, $VT.verbose_msg
            $NewFileSubmit += $item +"," +$VT.verbose_msg
            }
       else {  
             $VTError += $item +","+ $VT.verbose_msg
             }
}

# This is the start of the script
# The next line gets the content for submission and skips the first line the output from Splunk to remove the "Headers"
#$Hashes = get-content .\$HashFileName -Encoding Ascii 
$Hashes = import-csv .\myhashes.csv 



# This submits the URL's to virus total
 $x = 0
  foreach ($item in $Hashes.Hashes) { 
   if ($x -lt 4) {
      Set-VTApiKey -VTApiKey eebaaae76b2414da993c0ed8cef34d0c532a1200ae93a6daf04884ee4f2aa36b 
      . MyFunction "$item"
      $x++ 
    }
           
  else 
  {
    Start-Sleep -Seconds 59
    $x = 0
    }
 }
 
#This would add to our production vt-hash-out.csv uncomment when ready.
$myout | Export-Csv .\BSIDES-vt-hash-out.csv -NoTypeInformation -Append

# This puts out any other errors we might have with VT submissions  
$VTError | Out-File .\BSIDES-vt-error-out.log 

$NewFileSubmit | Out-File .\BSIDES-newfilesubmit.log 


