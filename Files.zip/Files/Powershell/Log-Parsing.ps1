﻿
# Using XML Example

Get-WinEvent -FilterXml $xmlfilter -maxevents 1 
[xml]$xmlfilter = @"
<QueryList>
  <Query Id="0" Path="Security">
    <Select Path="Security">*[System[(EventID=4624)]]</Select>
    </Query>
</QueryList>
"@

# Get a single event to look at properties
$a = Get-WinEvent -FilterHashtable @{logname="Security";id=4624} -MaxEvents 1 


Get-WinEvent -FilterHashtable @{logname="Security";Id=4624} -MaxEvents 10| Select-Object -Property timecreated, machinename, 
@{Name='SecurityId';Expression={$_.Properties[5].Value}},
@{Name='LogonType';Expression={$_.Properties[8].Value}},
@{Name='LogonProcessName';Expression={$_.Properties[9].Value}},
@{Name='Authentication';Expression={$_.Properties[10].Value}},
@{Name='ProcessName';Expression={$_.Properties[17].Value}},
@{Name='IPAddress';Expression={$_.Properties[18].Value}}


<#

https://gist.github.com/RamblingCookieMonster/da272fee3b9a879bfee9
https://gallery.technet.microsoft.com/scriptcenter/Get-WinEventData-Extract-344ad840
This works for Security and Sysmon logs
 
#>

# Require this module to pull out embedded events. Can be used as a function. Required for most scripts below
Import-Module .\Get-WinEventData.ps1

$a = Get-WinEvent -FilterHashtable @{logname="Security";id=4624} -MaxEvents 1 | 
Get-WinEventData | fl *


Get-WinEvent -FilterHashtable @{logname="Security";id=4624} -MaxEvents 10 | 
Get-WinEventData |Select-Object -Property TimeCreated,Computer,EventDataTargetUserName,EventDataLogonType,EventDataLogonProcessName,EventDataAuthenticationPackageName,EventDataProcessName,EventDataIpAddress 


# Event 4688
Get-WinEvent -FilterHashtable @{logname="Security";id=4688} -MaxEvents 100 | 
Get-WinEventData | 
Select-Object -Property TimeCreated,MachineName,EventDataSubjectUserName,EventDataNewProcessName |
ft -AutoSize


# output Event ID 1 for later analysis and review
$a=Get-WinEvent -FilterHashtable @{logname="Microsoft-Windows-Sysmon/Operational";id=1} -MaxEvents 10 | 
Get-WinEventData | Select-Object EventDataHashes, EventDataImage, EventDataParentImage 



# This took 2 min 54 seconds on 174 MB file
measure-command {
Get-WinEvent -FilterHashtable @{logname="Security";Id=4624} | Select-Object -Property timecreated, machinename, 
@{Name='SecurityId';Expression={$_.Properties[5].Value}},
@{Name='LogonType';Expression={$_.Properties[8].Value}},
@{Name='LogonProcessName';Expression={$_.Properties[9].Value}},
@{Name='Authentication';Expression={$_.Properties[10].Value}},
@{Name='ProcessName';Expression={$_.Properties[17].Value}},
@{Name='IPAddress';Expression={$_.Properties[18].Value}}
}

# This took 3 min 49 seconds on 174 MB file
Measure-Command { 
Get-WinEvent -FilterHashtable @{logname="Security";id=4624} | 
Get-WinEventData | 
Select-Object -Property TimeCreated,Computer,EventDataTargetUserName,EventDataLogonType,EventDataLogonProcessName,EventDataAuthenticationPackageName,EventDataProcessName,EventDataIpAddress 
}




